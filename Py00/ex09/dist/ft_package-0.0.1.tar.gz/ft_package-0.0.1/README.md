# ft_package_mhaouas
This package is the result of mhaouas' ninth exercice of the first day of the Python Pool from the 42 school.